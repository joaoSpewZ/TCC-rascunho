<?php
    session_start();
?>

<?php
include_once("../conexao.php");
include_once("../includes.php");
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../carro/style2.css"  />
<body>

<div class="container">
  <section class="header">
    <h2>CADASTRE O CARRO</h2>
  </section>

  <form id="form" class="form">
  <div class="form-content">
      <label for="marca">Marca</label>
      <input  id="marca" type="text" name="Modelo" class="form-control" placeholder="Preencha o Modelo"/>
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
      <label for="modelo">Modelo</label>
      <input  id="modelo" type="text" name="Modelo" class="form-control" placeholder="Preencha o Modelo"/>
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
      <label for="placa">Placa</label>
      <input  id="placa" size = "7" maxlength = "7" type="Placa" name="Placa" class="form-control" placeholder="Digite a Placa" style='text-transform:uppercase'/>
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
        <label for="preco">Preço</label>
        <input id="preco" type="text" name="preco" class="form-control" placeholder="Preencha o Preço">
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
        <label for="motorizacao">Motorização</label>
        <input id="motorizacao" type="text" name="motorizacao" class="form-control" placeholder="Preencha a Motorização">
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
        <label for="ano">Ano</label>
        <input id="ano" type="text"  name="ano" class="form-control" placeholder="Preencha o Ano">
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
        <label for="cor" class="form-label">Cor</label>
        <input id="cor" type="text" name="cor" class="form-control" placeholder="Preencha a Cor"> 
      <a>Aqui vai a mensagem de erro....</a>
    </div>

  <div>
    <label class="form-label">Automático</label>
        </div>
                        
            <div class="d-grid gap-4 col-100 d-md-flex  justify-content-md ">
            <div>
            <input type="radio" id="sim" name="automatico" value="sim" />
            <label for="sim">Sim</label>
            </div>
            <div>
            <input type="radio" id="nao" name="automatico" value="nao" />
            <label for="nao">Não</label>
            </div>
            </div>
            <div class="mb-3">
            </br>
            <label>Imagem</label>
            </br>
            <input type="file" name="imagem" class="form-control-file">
            </div>

                
        <button type="submit" name="salvarcarro" class="btn btn-primary">Salvar</button>

  </form>

</div>


<script src="../carro/script.js"></script>
</body>

    </html>
    