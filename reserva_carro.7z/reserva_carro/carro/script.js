
const form = document.getElementById("form");
const marca = document.getElementById("marca")
const modelo = document.getElementById("modelo")
const placa = document.getElementById("placa")



form.addEventListener("submit", (event) => {
  event.preventDefault();

  checkForm();
})

marca.addEventListener("blur", () => {
  checkInputMarca();
})

modelo.addEventListener("blur", () => {
  checkInputModelo();
})

placa.addEventListener("blur", () => {
  checkInputPlaca();
})

preco.addEventListener("blur", () => {
  checkInputPreco();
})

motorizacao.addEventListener("blur", () => {
  checkInputMotorizacao();
})

ano.addEventListener("blur", () => {
  checkInputAno();
})

cor.addEventListener("blur", () => {
  checkInputCor();
})

function checkInputMarca(){
  const marcaValue = marca.value;

  if(marcaValue === ""){
    errorInput(marca, "A marca é obrigatória.")
  }else{
    const formItem = marca.parentElement;
    formItem.className = "form-content"
  }


}


function checkInputPlaca(){
  const placaValue = placa.value;

  if(placaValue === ""){
    errorInput(placa, "A placa é obrigatória.")
  }else{
    const formItem = placa.parentElement;
    formItem.className = "form-content"
  }


}

function checkInputModelo(){
  const modeloValue = modelo.value;

  if(modeloValue === ""){
    errorInput(modelo, "Preencha o Modelo!")
  }else{
    const formItem = modelo.parentElement;
    formItem.className = "form-content"
  }

}

function checkInputPreco(){
  const precoValue = preco.value;

  if(precoValue === ""){
    errorInput(preco, "Digite o Preço...")
  }else{
    const formItem = preco.parentElement;
    formItem.className = "form-content"
  }

}

function checkInputMotorizacao(){
  const motorizacaoValue = motorizacao.value;

  if(motorizacaoValue === ""){
    errorInput(motorizacao, "Digite á Motorização...")
  }else{
    const formItem = motorizacao.parentElement;
    formItem.className = "form-content"
  }

}

function checkInputAno(){
  const anoValue = ano.value;

  if(anoValue === ""){
    errorInput(ano, "O Ano é obrigatório.")
  }else{
    const formItem = ano.parentElement;
    formItem.className = "form-content"
  }


}

function checkInputCor(){
  const corValue = cor.value;

  if(corValue === ""){
    errorInput(cor, "Digite á Cor!")
  }else{
    const formItem = cor.parentElement;
    formItem.className = "form-content"
  }

}


function checkForm(){
  checkInputMarca();
  checkInputModelo();
  checkInputPlaca();
  checkInputPreco();
  checkInputMotorizacao();
  checkInputAno();
  checkInputCor();

  const formItems = form.querySelectorAll(".form-content")

  const isValid = [...formItems].every( (item) => {
    return item.className === "form-content"
  });

  if(isValid){
    alert("CADASTRADO COM SUCESSO!")
  }

}


function errorInput(input, message){
  const formItem = input.parentElement;
  const textMessage = formItem.querySelector("a")

  textMessage.innerText = message;

  formItem.className = "form-content error"

}