insert into funcionario (nome,cpf,email,telefone,funcao,emprego,sexo)
 values ("rafael","94020192","rafael@gmail.com","42718724","entregador","muffato","masculino");
insert into login (usuario,senha,tipo,funcionario_idfuncionario)
 values ("admin","8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918","1","1");

//o usuário e a senha do login que está criptografado é "admin".