<?php
    session_start();
?>

<link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../carro/style2.css"  />
<body>
    <header>
    <nav class="nav-bar">
            <div class="logo">
                <h1>Logo</h1>
            </div>
            <div class="nav-list">
                <ul>
                    <li class="nav-item"><a href="index.php" class="nav-link">Início</a></li>
                    <li class="nav-item"><a href="carros.html" class="nav-link">Carros</a></li>
                    <li class="nav-item"><a href="#" class="nav-link">Reservados</a></li>
                </ul>
            </div>
            <div class="mobile-menu-icon">
                <button onclick="menuShow()"><img class="icon" src="../img/menu_white_36dp.svg" alt=""></button>
            </div>
        </nav>
        <div class="mobile-menu">
            <ul>
                <li class="nav-item"><a href="index.php" class="nav-link">Início</a></li>
                <li class="nav-item"><a href="carros.html" class="nav-link">Carros</a></li>
                <li class="nav-item"><a href="#" class="nav-link">Reservados</a></li>
            </ul>
        </div>
    </header>

<div class="container">
  <section class="her">
    <h2>CADASTRE O CARRO</h2>
  </section>

  <form id="form" class="form">
  <div class="form-content">
      <label for="marca">Marca</label>
      <input  id="marca" type="text" name="Modelo" class="form-control" placeholder="Preencha o Modelo"/>
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
      <label for="modelo">Modelo</label>
      <input  id="modelo" type="text" name="Modelo" class="form-control" placeholder="Preencha o Modelo"/>
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
      <label for="placa">Placa</label>
      <input  id="placa" size = "7" maxlength = "7" type="Placa" name="Placa" class="form-control" placeholder="Digite a Placa" style='text-transform:uppercase'/>
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
        <label for="preco">Preço</label>
        <input id="preco" type="number" name="preco" class="form-control" placeholder="Preencha o Preço">
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
        <label for="motorizacao">Motorização</label>
        <input id="motorizacao" type="text" name="motorizacao" class="form-control" placeholder="Preencha a Motorização">
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
        <label for="ano">Ano</label>
        <input id="ano" type="number"  name="ano" class="form-control" placeholder="Preencha o Ano">
      <a>Aqui vai a mensagem de erro....</a>
    </div>

    <div class="form-content">
        <label for="cor" class="form-label">Cor</label>
        <input id="cor" type="text" name="cor" class="form-control" placeholder="Preencha a Cor"> 
      <a>Aqui vai a mensagem de erro....</a>
    </div>

  <div>
    <label class="form-label">Automático</label>
        </div>
                        
            <div class="d-grid gap-4 col-100 d-md-flex  justify-content-md ">
            <div>
            <input type="radio" id="sim" name="automatico" value="sim" />
            <label for="sim">Sim</label>
            </div>
            <div>
            <input type="radio" id="nao" name="automatico" value="nao" />
            <label for="nao">Não</label>
            </div>
            </div>
            <div class="mb-3">
            </br>
            <label>Imagem</label>
            </br>
            <input type="file" name="imagem" class="form-control-file">
            </div>

                
        <button type="submit" name="salvarcarro" class="btn btn-primary">Salvar</button>

  </form>

</div>


<script src="../carro/script.js"></script>
<script src="../carro/script2.js"></script>
</body>

    </html>
    